terminal.js-webshell
====================

this is a demo application for [child_pty](https://github.com/Gottox/child_pty) and [terminal.js](https://github.com/Gottox/terminal.js).

running this demo
-----------------

```
npm install
npm start
```

Then point your browser to http://127.0.0.1:3000

![Demo](https://raw.githubusercontent.com/Gottox/terminal.js-webshell/master/demo.gif)
